# Corne Choc Pro BT – ZMK keymap (Colemak-DH, German)

Personal [ZMK](https://zmk.dev) configuration for the **Keebart Corne Choc Pro BT** (46-key version,
wireless, one rotary encoder and one extra key per half). It is a fork of
[Keebart/zmk-config](https://github.com/Keebart/zmk-config), built in the cloud with GitHub Actions.

**Printable key reference:** [`docs/keymap-reference.pdf`](docs/keymap-reference.pdf)
(A4 landscape, one layer per page, print at 100 % – the drawing is approximately life-size).

| | |
|---|---|
| Base layout | Colemak-DH (letters), German locale codes (`DE_*`) |
| Umlauts | Hold the key: U → Ü, A → Ä, O → Ö, S → ß (hold-tap) |
| Layers | Base, Lower (numbers/system), Raise (symbols), Function (F-keys) |
| Tested on | macOS with input source **Deutsch Standard**. Windows: not tested yet |

---

## Layers

| # | Layer | How to reach it | Purpose |
|---|---|---|---|
| 0 | Base | default | Colemak-DH letters, modifiers, Esc/Tab/Backspace/Delete |
| 1 | Lower | hold left thumb, middle key | Number pad, arrows, Bluetooth, LED, reset/bootloader |
| 2 | Raise | hold right thumb, middle key | German symbol set |
| 3 | Function | hold Lower **and** Raise | F1–F12, Print Screen, Scroll Lock, Pause, LED hue |

Keys drawn grey and dashed are transparent (`&trans`): they are not changed on that layer and fall through
to the layer below.

### Layer 0 – Base

![Base layer](docs/img/layer-0-base.png)

### Layer 1 – Lower

![Lower layer](docs/img/layer-1-lower.png)

### Layer 2 – Raise

![Raise layer](docs/img/layer-2-raise.png)

### Layer 3 – Function

![Function layer](docs/img/layer-3-function.png)

F1–F10 are on the top row (F1–F5 left, F6–F10 right). F11, F12 and Hue −/+ are on the left home row (positions 15–18),
and Print Screen, Scroll Lock and Pause are on the right home row (positions 22–24). All other keys fall through to
the Raise layer.

---

## Special behaviour

### Umlauts and ß (hold-tap)

`A`, `O`, `U` and `S` are hold-taps: **tap** = the letter, **hold** = Ä, Ö, Ü, ß. The behaviour is defined once
in the keymap and used on four keys:

```c
umlaut: umlaut_holdtap {
    compatible = "zmk,behavior-hold-tap";
    #binding-cells = <2>;
    tapping-term-ms = <220>;
    quick-tap-ms = <150>;
    require-prior-idle-ms = <120>;
    flavor = "tap-preferred";
    bindings = <&kp>, <&kp>;
};
// usage: &umlaut <hold keycode> <tap keycode>, e.g. &umlaut DE_A_UMLAUT DE_A
```

What the parameters do:

| Parameter | Meaning |
|---|---|
| `tapping-term-ms` | How long you must hold before the umlaut is sent |
| `require-prior-idle-ms` | If another key was pressed less than this long ago, the key is always a plain tap (protects fast typing, e.g. "Feuer", "Auge") |
| `quick-tap-ms` | A second press shortly after a tap is always a tap (double vowels like "Boot", "Aal", and key repeat) |
| `flavor = "tap-preferred"` | When in doubt the plain letter wins, never the umlaut |

Tuning (change the value, commit, wait for the build, flash **both** halves):

| Symptom | Change |
|---|---|
| Umlaut appears when you wanted the plain letter | raise `tapping-term-ms` (e.g. 240–260) or raise `require-prior-idle-ms` |
| Umlaut feels hard to trigger / hold takes too long | lower `tapping-term-ms` (e.g. 180–200) |
| Umlaut right after another key does not work | lower `require-prior-idle-ms` (the key before must be at least this long ago) |
| Double letters (oo, aa) misfire | raise `quick-tap-ms` (e.g. 200) |

The `S` key is the most frequently typed of the four, so it is the first place to notice a bad setting.

### Rotary encoders

| Encoder | Turn | Click |
|---|---|---|
| Left | Page Up / Page Down | Play / Pause |
| Right | Volume | Mute |

The turn actions are defined in `sensor-bindings` of the **base layer** and apply on every layer. The four entries
belong to the encoder slots in the order `left_ex1, left_ex2, right_ex1, right_ex2`
(see `boards/arm/corne_choc_pro/corne_choc_pro.dtsi`). On this board the populated slots are entry 2 (left,
`PG_UP`/`PG_DN`) and entry 4 (right, volume), checked by turning the encoders. Entries 1 and 3 belong to unpopulated
slots (plain keys) and keep Keebart's defaults. Keep all four entries.

To reverse the direction of an encoder, swap the two keycodes in its entry
(e.g. `&inc_dec_kp C_VOL_DN C_VOL_UP` ↔ `&inc_dec_kp C_VOL_UP C_VOL_DN`).

### Bluetooth, output and system keys (Lower layer)

| Key | Position | Action |
|---|---|---|
| BT0 … BT4 | 1–5 | Select Bluetooth profile 0–4 |
| BT clear | 29 | Remove the pairing of the **current** profile |
| USB/BT | 19 | `&out OUT_TOG` – toggle the output between USB and Bluetooth |
| LED on/off | 30 | `&rgb_ug RGB_TOG` |
| Reset | 31 | `&sys_reset` |
| Bootloader | 32 | `&bootloader` – puts the half into flashing mode |
| Studio unlock | 33 | `&studio_unlock` – ZMK Studio (enabled in the left-half build). Studio changes live on the keyboard and are **not** saved in this repo |

Reset and Bootloader are for recovery and flashing; press them deliberately.

### LEDs

LED control is limited to on/off (Lower) and hue −/+ (Function layer, positions 17/18). There is no brightness or
saturation key; hue has no visible effect while saturation is 0 (white).

**The halves have no charge indicator and no display.** LEDs drain the battery noticeably: with a low battery
and the LEDs on, the right half once turned yellow and shut down until it was plugged in. Charge it (overnight
is fine) and keep the LEDs off when you do not need them.

### Dead keys and the degree sign

`´`, `` ` `` and `^` are dead keys on the German layout: they wait for the next key. Press **Space** afterwards to
get the plain character. `°` = hold the left Shift and press the `^` key (derived from `keys_de.h`, not yet
tested on the hardware). `:` = Shift + `.`.

### Clipboard

There are no combos. Cut/copy/paste use the normal shortcuts (Cmd+X/C/V on macOS) with the Cmd key on the left thumb.

---

## Requirements on the computer

* **macOS: input source "Deutsch Standard"** – not the older "Deutsch". The two differ in their Option-key
  symbols, and `@ [ ] { } | \ ~` come out wrong with "Deutsch".
* **No Colemak (or other layout) input source active.** Colemak-DH is done by the keyboard; an additional
  layout on the computer would remap the letters a second time.
* The keymap uses `keys_de.h` (generated by the ZMK Locale Generator) so that the keyboard sends the codes a
  German layout expects. The file lives in `config/` and is included in `config/corne_choc_pro.keymap`.

---

## Build and flash

1. Edit `config/corne_choc_pro.keymap` on GitHub (see below) and commit.
2. Open **Actions** in the repository and wait for the run to finish (green check).
3. Download the artifacts **`corne_choc_pro_bt_left`** and **`corne_choc_pro_bt_right`** and unzip them.
   The `*_5col_*` artifacts are for the 40-key version and must **not** be used on this board.
4. Connect a half by USB-C and **double-tap its reset button**. A drive appears; drag the matching `.uf2` file onto it.
   The drive disappears when the flash is done.
5. Repeat for the other half. Use files from the **same** build for both halves.
6. If the computer no longer connects: remove the keyboard in the Bluetooth settings, press **BT clear** on the
   Lower layer, and pair again.

If the halves do not find each other after flashing, flash the `settings_reset` firmware (also built by the workflow)
on both halves, then the normal firmware again. This clears all stored settings including Bluetooth pairings.

Keebart's template workflow references `zmkfirmware/zmk/.github/workflows/build-user-config.yml@v0.3`.
**Keep `@v0.3`:** with `@main` the build fails on Keebart's board definitions (Zephyr 4.1 board-qualifier check).
GitHub Actions must be enabled once in a fork (Actions tab).

---

## Editing the keymap

The visual keymap editor can no longer parse the file (it does not understand the `DE_*` keycodes). Edit the
source directly on GitHub: `config/corne_choc_pro.keymap` → pencil icon.

**Position numbers** (the order of the entries in every `bindings` block):

| Row | Positions | Notes |
|---|---|---|
| 1 | 0–13 | 0 outer, 1–5 left letters, **6** inner key (left), **7** inner key (right), 8–12 right letters, 13 outer |
| 2 | 14–27 | as row 1; **20** and **21** are the encoder clicks |
| 3 | 28–39 | no inner keys: 28 outer, 29–33 left, 34–38 right, 39 outer |
| Thumbs | 40–45 | 40 Cmd/Win, **41 Lower**, 42 Space, 43 Enter, **44 Raise**, 45 Ctrl |

Rules that keep the keymap working:

* Every layer needs exactly **46 entries**, laid out as 14 / 14 / 12 / 6.
* Layer indices: 0 Base, 1 Lower, 2 Raise, 3 Function (`extra_layer_1`), 4–8 unused placeholders. The Function layer is
  a conditional layer (`if-layers = <1 2>; then-layer = <3>;`).
* **Position 44 must stay `&mo 2` on the Lower layer, and position 41 must stay `&mo 1` on the Raise layer.** Otherwise
  the second thumb key is shadowed and Lower + Raise cannot be held in either order.
* Use `DE_*` codes for letters and symbols. Plain codes (`F1`, `LEFT`, `LGUI`, `BSPC` …) are fine for keys that do
  not depend on the OS layout. The number pad on the Lower layer deliberately uses keypad codes (`KP_N0`–`KP_N9`).
* `#include "keys_de.h"` must come after the other includes.
* Keep the comment headers above each layer in sync with the bindings.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Y and Z swapped, many symbols wrong | Firmware built without `keys_de.h` (wrong branch or old build), or the OS layout is not German | Flash a build from the correct branch; check the OS input source |
| `@ [ ] { } \| \ ~` wrong on macOS | Input source "Deutsch" instead of "Deutsch Standard" | Switch to "Deutsch Standard" |
| Letters scrambled in a different way | An extra Colemak input source is active on the computer | Remove it; use only German |
| No workflow shown under Actions | Actions disabled in the fork | Enable Actions; make sure `build.yaml` is in the repository root |
| Build fails with an error about `qualifiers` / ZMK variant | Workflow uses `@main` | Use `@v0.3` |
| Keys wrong right after flashing | Flashed a `*_5col_*` or older artifact | Flash `corne_choc_pro_bt_*` from the latest run of the right branch |
| USB works, Bluetooth silent | Stale pairing, or output set to USB | Remove the device in the OS, **BT clear**, pair again; try **USB/BT** with the cable unplugged |
| A half goes dark or the LEDs turn yellow | Low battery under LED load | Charge it; keep the LEDs off or dim |
| Umlaut appears unintentionally, or is hard to get | Hold-tap timing | See the tuning table above |
| Function layer does not appear | Only one layer key is held, or the layer-key rule above is broken | Hold Lower and Raise together; check positions 41/44 |

---

## Known limitations and ideas

* **Windows is untested.** Things to check: the keypad digits and Num Lock, `KP_EQUAL` (probably ignored by Windows;
  unverified), and the `DE_*` symbols with a German layout.
* Keypad codes on the Lower layer are layout-independent on macOS; behaviour with Num Lock off on Windows is untested.
* No LED brightness/saturation keys; encoder behaviour is the same on all layers.
* Print Screen, Scroll Lock and Pause do little on macOS.
* Idea: rebuild the Raise layer by symbol frequency (brackets, `=`, `_`, `-` on the home row) instead of the German
  number-row order, once the board feels automatic.
* Idea: per-layer encoder actions.
* Layers 4–8 (`extra_layer_2` … `extra_layer_6`) are unused placeholders.

---

## Design decisions in short

* **Colemak-DH** because it is made for column-staggered boards. Letters and symbols use the **German locale header**
  instead of switching the OS to a US layout, because the computer always runs a German layout.
* **Umlauts by hold-tap on the vowels** (not a separate layer and not tap-dance): no extra key needed, and the safeguards
  (`tap-preferred`, `require-prior-idle-ms`) keep fast typing safe.
* **Number pad on the right hand, held with the left thumb**, so numbers can be typed one-handed.
* **Two Shift keys, Ctrl on the right thumb, Esc and Tab in the left outer column.**
* No home-row mods and no combos for now – one new habit at a time.

## Credits

* [ZMK Firmware](https://zmk.dev)
* [Keebart/zmk-config](https://github.com/Keebart/zmk-config) – board definitions and the original keymap
* [zmk-locale-generator](https://github.com/joelspadin/zmk-locale-generator) – `keys_de.h`
  (the header carries its own Unicode data license notice)
